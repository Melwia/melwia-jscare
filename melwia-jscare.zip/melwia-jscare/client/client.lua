local QBCore = exports['qb-core']:GetCoreObject()
local jscarePlaying = false

RegisterNetEvent('jscare:client:showJumpscare')
AddEventHandler('jscare:client:showJumpscare', function()
    if not jscarePlaying then
        jscarePlaying = true
        
        SendNUIMessage({
            type = "showJumpscare",
            display = true
        })
        
        SetNuiFocus(false, false)
        
        Citizen.Wait(4000)
        
        SendNUIMessage({
            type = "showJumpscare",
            display = false
        })
        
        jscarePlaying = false
    end
end)

