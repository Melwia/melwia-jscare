local QBCore = exports['qb-core']:GetCoreObject()

QBCore.Commands.Add('jscare', 'ADK, MDK ve DDK İhtimali %100 Olan Komut', {{name = 'id', help = 'Player ID'}}, true, function(source, args)
    local src = source
    local targetId = tonumber(args[1])
    
    if not targetId then
        TriggerClientEvent('QBCore:Notify', src, 'Yanlış ID', 'error')
        return
    end
    
    local targetPlayer = QBCore.Functions.GetPlayer(targetId)
    if not targetPlayer then
        TriggerClientEvent('QBCore:Notify', src, 'Oyuncu Bulunamadı', 'error')
        return
    end
    
    TriggerClientEvent('jscare:client:showJumpscare', targetId)
end, 'god')

