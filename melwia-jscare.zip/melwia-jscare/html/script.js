$(() => {
  window.addEventListener("message", (event) => {
    if (event.data.type === "showJumpscare") {
      if (event.data.display) {
        $("#jumpscare-container").fadeIn(100)
        var audio = document.getElementById("jumpscare-sound")
        audio.volume = 1.0
        audio.play()
      } else {
        $("#jumpscare-container").fadeOut(500)
      }
    }
  })
})

