fx_version 'cerulean'
game 'gta5'

author 'melwia'
description 'altına sıçan yorumu beğensin'
version '1.0.0'

client_scripts {
    'client/client.lua'
}

server_scripts {
    'server/server.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/jscare.png',
    'html/jscare.mp3',
    'html/script.js'
}

